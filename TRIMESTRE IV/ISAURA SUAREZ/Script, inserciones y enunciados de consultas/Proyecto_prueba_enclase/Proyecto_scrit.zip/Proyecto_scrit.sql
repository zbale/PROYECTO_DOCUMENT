CREATE DATABASE Proyecto3;
USE Proyecto3;

CREATE TABLE Usuario (
  id_usuario INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  apellido VARCHAR(50) NOT NULL,
  telefono VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  direccion VARCHAR(50),
  tipo_usuario ENUM('cliente', 'administrador') NOT NULL
);


CREATE TABLE  Factura (
  id_factura INT PRIMARY KEY AUTO_INCREMENT,
  metodo_pago VARCHAR(45) NOT NULL,
  fecha_factura VARCHAR(45) NOT NULL,
  idntificancion_cliente VARCHAR(45) NOT NULL,
  fecha DATE NOT NULL,
  total DECIMAL(10, 2) NOT NULL,
  id_cliente INT NOT NULL,
  FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
);

CREATE TABLE Producto (
  id_producto INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  descripcion TEXT,
  precio DECIMAL(10, 2) NOT NULL,
  stock VARCHAR(45) NOT NULL
);


CREATE TABLE Detalle_Factura (
  id_detalle INT PRIMARY KEY AUTO_INCREMENT,
  cantidad INT NOT NULL,
  descuento DECIMAL(5,2) DEFAULT 0 CHECK (descuento BETWEEN 0 AND 100),
  id_factura INT NOT NULL,
  id_producto INT NOT NULL,
  FOREIGN KEY (id_factura) REFERENCES Factura(id_factura),
  FOREIGN KEY (id_producto) REFERENCES Producto(id_producto)
);

CREATE TABLE Categoria_Producto (
  id_categoria INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL
);

CREATE TABLE Producto_Categoria (
  id_producto INT NOT NULL,
  id_categoria INT NOT NULL,
  PRIMARY KEY (id_producto, id_categoria),
  FOREIGN KEY (id_producto) REFERENCES Producto(id_producto),
  FOREIGN KEY (id_categoria) REFERENCES Categoria_Producto(id_categoria)
);



