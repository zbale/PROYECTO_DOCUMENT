CREATE DATABASE Proyecto3;
USE Proyecto3;

CREATE TABLE Usuario (
  id_usuario INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  apellido VARCHAR(50) NOT NULL,
  telefono VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  direccion VARCHAR(50),
  tipo_usuario ENUM('cliente', 'administrador') NOT NULL
);


CREATE TABLE  Factura (
  id_factura INT PRIMARY KEY AUTO_INCREMENT,
  metodo_pago VARCHAR(45) NOT NULL,
  fecha_factura VARCHAR(45) NOT NULL,
  idntificancion_cliente VARCHAR(45) NOT NULL,
  fecha DATE NOT NULL,
  total DECIMAL(10, 2) NOT NULL,
  id_cliente INT NOT NULL,
  FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
);

CREATE TABLE Producto (
  id_producto INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  descripcion TEXT,
  precio DECIMAL(10, 2) NOT NULL,
  stock VARCHAR(45) NOT NULL
);


CREATE TABLE Detalle_Factura (
  id_detalle INT PRIMARY KEY AUTO_INCREMENT,
  cantidad INT NOT NULL,
  descuento DECIMAL(5,2) DEFAULT 0 CHECK (descuento BETWEEN 0 AND 100),
  id_factura INT NOT NULL,
  id_producto INT NOT NULL,
  FOREIGN KEY (id_factura) REFERENCES Factura(id_factura),
  FOREIGN KEY (id_producto) REFERENCES Producto(id_producto)
);

CREATE TABLE Categoria_Producto (
  id_categoria INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL
);

CREATE TABLE Producto_Categoria (
  id_producto INT NOT NULL,
  id_categoria INT NOT NULL,
  PRIMARY KEY (id_producto, id_categoria),
  FOREIGN KEY (id_producto) REFERENCES Producto(id_producto),
  FOREIGN KEY (id_categoria) REFERENCES Categoria_Producto(id_categoria)
);

CREATE TABLE Carro_Compra (
  id_carro INT PRIMARY KEY AUTO_INCREMENT,
  id_Usuario INT NOT NULL,
  id_producto INT NOT NULL,
  cantidad INT NOT NULL CHECK (cantidad > 0),
  agregado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_Usuario) REFERENCES Usuario(id_usuario),
  FOREIGN KEY (id_producto) REFERENCES Producto(id_producto)
);


-- insersiones de usuarios..
INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Andres', 'Lopez', '320-456-7890', 'andreslopez@email.com', 'Calle 45 #12-34, Bogota', 'cliente');

INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Carolina', 'Ramirez', '310-987-6543', 'carolinaramirez@email.com', 'Carrera 20 #56-78, Medellin', 'cliente');

INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Javier', 'Torres', '322-123-4567', 'javiertorres@email.com', 'Avenida Principal #78-90, Cali', 'cliente');

INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Maria Fernanda', 'Castro', '313-789-0123', 'mariafernandacastro@email.com', 'Calle 10 #5-67, Barranquilla', 'cliente');

INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Alejandro', 'Gomez', '311-555-6789', 'alejandrogomez@email.com', 'Transversal 33 #44-22, Cartagena', 'cliente');

INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Jose', 'ZABALETA', '323-599-5105', 'josezabaleta5@email.com', 'Carrera 80 #23-19, Bucaramanga', 'administrador');

INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Miguel', 'Torres', '301-777-8888', 'migueltorres@email.com', 'Calle 90 #8-45, Pereira', 'administrador');

INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Michael', 'Vasquez', '316-222-3333', 'michaelvazquez@email.com', 'Diagonal 12 #34-56, Manizales', 'administrador');

INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Sebastian', 'Vargas', '312-999-0000', 'sebastianvargas@email.com', 'Carrera 67 #45-89, Cucuta', 'cliente');

INSERT INTO Usuario (nombre, apellido, telefono, email, direccion, tipo_usuario) 
VALUES ('Jose', 'Daza', '305-111-2222', 'josedaza@email.com', 'Calle 23 #11-78, Villavicencio', 'administrador');

-- insersiones de Factura
INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Tarjeta de credito', '2025-03-13', 'CC123456', '2025-03-13', 50000, 1);

INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Efectivo', '2025-03-12', 'CC789012', '2025-03-12', 75000, 2);

INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Transferencia', '2025-03-11', 'CC345678', '2025-03-11', 120000, 3);

INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Tarjeta de debito', '2025-03-10', 'CC901234', '2025-03-10', 35000, 4);

INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Efectivo', '2025-03-09', 'CC567890', '2025-03-09', 80000, 5);

INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Tarjeta de credito', '2025-03-08', 'CC112233', '2025-03-08', 95000, 6);

INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Transferencia', '2025-03-07', 'CC445566', '2025-03-07', 110000, 7);

INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Efectivo', '2025-03-06', 'CC778899', '2025-03-06', 62000, 8);

INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Tarjeta de debito', '2025-03-05', 'CC990011', '2025-03-05', 47000, 9);

INSERT INTO Factura (metodo_pago, fecha_factura, idntificancion_cliente, fecha, total, id_cliente) 
VALUES ('Efectivo', '2025-03-04', 'CC223344', '2025-03-04', 88000, 10);

-- Insersiones de Producto
INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Laptop HP', 'Laptop HP 15" con procesador Intel i5 y 8GB RAM', 2500000, '20');

INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Mouse Inalambrico', 'Mouse ergonomico con conexion Bluetooth', 75000, '50');

INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Teclado mecanico', 'Teclado mecanico RGB con switches rojos', 180000, '35');

INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Monitor Samsung', 'Monitor LED de 24" con resolucion Full HD', 550000, '15');

INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Disco SSD 1TB', 'Disco de estado solido NVMe de 1TB', 420000, '25');

INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Audifonos Bluetooth', 'Audifonos inalambricos con cancelacion de ruido', 320000, '40');

INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Silla Gamer', 'Silla ergonomica con soporte lumbar', 600000, '10');

INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Impresora Epson', 'Impresora multifuncional con conexion WiFi', 450000, '12');

INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Tablet Samsung', 'Tablet de 10.4" con 64GB de almacenamiento', 900000, '18');

INSERT INTO Producto (nombre, descripcion, precio, stock) 
VALUES ('Cargador Universal', 'Cargador de 65W compatible con varios modelos', 120000, '30');

-- insersiones de Detalle_Factura

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (2, 10.00, 1, 1);

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (1, 5.50, 2, 3);

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (3, 0.00, 3, 2);

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (5, 15.00, 4, 4);

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (4, 20.00, 5, 5);

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (2, 10.00, 6, 6);

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (1, 0.00, 7, 7);

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (3, 25.00, 8, 8);

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (6, 30.00, 9, 9);

INSERT INTO Detalle_Factura (cantidad, descuento, id_factura, id_producto) 
VALUES (4, 5.00, 10, 10);

-- Insersiones de Categoria_Producto
INSERT INTO Categoria_Producto (nombre) 
VALUES ('Electronica');
INSERT INTO Categoria_Producto (nombre)
VALUES ('Accesorios');
INSERT INTO Categoria_Producto (nombre) 
VALUES ('Muebles');
INSERT INTO Categoria_Producto (nombre) 
VALUES ('Impresoras');
INSERT INTO Categoria_Producto (nombre) 
VALUES ('Tablets');

-- Insersiones de Producto_Categoria
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (1, 1);
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (2, 2); 
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (3, 2); 
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (4, 1);
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (5, 1); 
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (6, 2); 
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (7, 3); 
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (8, 4); 
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (9, 5); 
INSERT INTO Producto_Categoria (id_producto, id_categoria) 
VALUES (10, 2); 

-- Insersiones del carro de compras 
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (1, 2, 3);
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (2, 4, 2);
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (3, 1, 1);
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (4, 5, 4);
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (5, 3, 2);
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (6, 6, 1);
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (7, 7, 5);
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (8, 8, 2);
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (9, 9, 3);
INSERT INTO Carro_Compra (id_usuario, id_producto, cantidad) 
VALUES (10, 10, 1);











